﻿using System;
using System.IO;

class Program
{
    struct Person
    {
        public string name;
        public string address;
        public string fatherName;
        public string motherName;
        public long mobileNo;
        public string sex;
        public string email;
        public string citizenNo;
    }

    static void Main(string[] args)
    {
        Console.ForegroundColor = ConsoleColor.White;
        Console.BackgroundColor = ConsoleColor.Magenta;
        Console.Clear();
        Start();
    }

    static void Back()
    {
        Start();
    }

    static void Start()
    {
        Menu();
    }

    static void Menu()
    {
        Console.Clear();
        Console.WriteLine("\t\t**********WELCOME TO PHONEBOOK*************");
        Console.WriteLine("\n\n\t\t\t MENU\t\t\n\n");
        Console.WriteLine("\t1. Add New \t2. List \t3. Exit \n\t4. Modify \t5. Search\t6. Delete");

        switch (Console.ReadKey(true).KeyChar)
        {
            case '1':
                AddRecord();
                break;
            case '2':
                ListRecord();
                break;
            case '3':
                Environment.Exit(0);
                break;
            case '4':
                ModifyRecord();
                break;
            case '5':
                SearchRecord();
                break;
            case '6':
                DeleteRecord();
                break;
            default:
                Console.Clear();
                Console.WriteLine("\nEnter 1 to 6 only");
                Console.WriteLine("\n Enter any key");
                Console.ReadKey();
                Menu();
                break;
        }
    }

    static void AddRecord()
    {
        Console.Clear();
        Person p = new Person();

        Console.WriteLine("\n Enter name: ");
        p.name = Console.ReadLine();
        Console.WriteLine("\nEnter the address: ");
        p.address = Console.ReadLine();
        Console.WriteLine("\nEnter father name: ");
        p.fatherName = Console.ReadLine();
        Console.WriteLine("\nEnter mother name: ");
        p.motherName = Console.ReadLine();
        Console.WriteLine("\nEnter phone no.:");
        p.mobileNo = long.Parse(Console.ReadLine());
        Console.WriteLine("Enter sex:");
        p.sex = Console.ReadLine();
        Console.WriteLine("\nEnter e-mail:");
        p.email = Console.ReadLine();
        Console.WriteLine("\nEnter citizen no:");
        p.citizenNo = Console.ReadLine();

        using (BinaryWriter writer = new BinaryWriter(File.Open("project.dat", FileMode.Append)))
        {
            writer.Write(p.name);
            writer.Write(p.address);
            writer.Write(p.fatherName);
            writer.Write(p.motherName);
            writer.Write(p.mobileNo);
            writer.Write(p.sex);
            writer.Write(p.email);
            writer.Write(p.citizenNo);
        }

        Console.WriteLine("\nrecord saved");
        Console.WriteLine("\n\nEnter any key");
        Console.ReadKey();
        Console.Clear();
        Menu();
    }

    static void ListRecord()
    {
        Console.Clear();

        if (!File.Exists("project.dat"))
        {
            Console.WriteLine("\nfile opening error in listing :");
            Environment.Exit(1);
        }

        using (BinaryReader reader = new BinaryReader(File.Open("project.dat", FileMode.Open)))
        {
            while (reader.BaseStream.Position != reader.BaseStream.Length)
            {
                Person p = new Person
                {
                    name = reader.ReadString(),
                    address = reader.ReadString(),
                    fatherName = reader.ReadString(),
                    motherName = reader.ReadString(),
                    mobileNo = reader.ReadInt64(),
                    sex = reader.ReadString(),
                    email = reader.ReadString(),
                    citizenNo = reader.ReadString()
                };

                Console.WriteLine("\n\n\n YOUR RECORD IS\n\n ");
                Console.WriteLine($"\nName={p.name}\nAddress={p.address}\nFather name={p.fatherName}\nMother name={p.motherName}\nMobile no={p.mobileNo}\nSex={p.sex}\nE-mail={p.email}\nCitizen no={p.citizenNo}");
                Console.ReadKey();
                Console.Clear();
            }
        }

        Console.WriteLine("\n Enter any key");
        Console.ReadKey();
        Console.Clear();
        Menu();
    }

    static void SearchRecord()
    {
        Console.Clear();

        if (!File.Exists("project.dat"))
        {
            Console.WriteLine("\n error in opening");
            Environment.Exit(1);
        }

        Console.WriteLine("\nEnter name of person to search\n");
        string name = Console.ReadLine();

        using (BinaryReader reader = new BinaryReader(File.Open("project.dat", FileMode.Open)))
        {
            while (reader.BaseStream.Position != reader.BaseStream.Length)
            {
                Person p = new Person
                {
                    name = reader.ReadString(),
                    address = reader.ReadString(),
                    fatherName = reader.ReadString(),
                    motherName = reader.ReadString(),
                    mobileNo = reader.ReadInt64(),
                    sex = reader.ReadString(),
                    email = reader.ReadString(),
                    citizenNo = reader.ReadString()
                };

                if (p.name == name)
                {
                    Console.WriteLine($"\n\tDetail Information About {name}");
                    Console.WriteLine($"\nName: {p.name}\naddress: {p.address}\nFather name: {p.fatherName}\nMother name: {p.motherName}\nMobile no: {p.mobileNo}\nsex: {p.sex}\nEmail: {p.email}\nCitizen no: {p.citizenNo}");
                }
                else
                {
                    Console.WriteLine("file not found");
                }
            }
        }

        Console.WriteLine("\n Enter any key");
        Console.ReadKey();
        Console.Clear();
        Menu();
    }

    static void DeleteRecord()
    {
        Console.Clear();

        if (!File.Exists("project.dat"))
        {
            Console.WriteLine("CONTACT'S DATA NOT ADDED YET.");
        }
        else
        {
            Console.WriteLine("Enter CONTACT'S NAME:");
            string name = Console.ReadLine();

            bool flag = false;

            using (BinaryReader reader = new BinaryReader(File.Open("project.dat", FileMode.Open)))
            using (BinaryWriter writer = new BinaryWriter(File.Open("temp.dat", FileMode.Create)))
            {
                while (reader.BaseStream.Position != reader.BaseStream.Length)
                {
                    Person p = new Person
                    {
                        name = reader.ReadString(),
                        address = reader.ReadString(),
                        fatherName = reader.ReadString(),
                        motherName = reader.ReadString(),
                        mobileNo = reader.ReadInt64(),
                        sex = reader.ReadString(),
                        email = reader.ReadString(),
                        citizenNo = reader.ReadString()
                    };

                    if (p.name != name)
                    {
                        writer.Write(p.name);
                        writer.Write(p.address);
                        writer.Write(p.fatherName);
                        writer.Write(p.motherName);
                        writer.Write(p.mobileNo);
                        writer.Write(p.sex);
                        writer.Write(p.email);
                        writer.Write(p.citizenNo);
                    }
                    else
                    {
                        flag = true;
                    }
                }
            }

            File.Delete("project.dat");
            File.Move("temp.dat", "project.dat");

            if (flag)
            {
                Console.WriteLine("RECORD DELETED SUCCESSFULLY.");
            }
            else
            {
                Console.WriteLine("NO CONTACT'S RECORD TO DELETE.");
            }
        }

        Console.WriteLine("\n Enter any key");
        Console.ReadKey();
        Console.Clear();
        Menu();
    }

    static void ModifyRecord()
    {
        Console.Clear();

        if (!File.Exists("project.dat"))
        {
            Console.WriteLine("CONTACT'S DATA NOT ADDED YET.");
            Environment.Exit(1);
        }

        Console.WriteLine("\nEnter CONTACT'S NAME TO MODIFY:\n");
        string name = Console.ReadLine();

        bool flag = false;

        using (BinaryReader reader = new BinaryReader(File.Open("project.dat", FileMode.Open)))
        using (BinaryWriter writer = new BinaryWriter(File.Open("temp.dat", FileMode.Create)))
        {
            while (reader.BaseStream.Position != reader.BaseStream.Length)
            {
                Person p = new Person
                {
                    name = reader.ReadString(),
                    address = reader.ReadString(),
                    fatherName = reader.ReadString(),
                    motherName = reader.ReadString(),
                    mobileNo = reader.ReadInt64(),
                    sex = reader.ReadString(),
                    email = reader.ReadString(),
                    citizenNo = reader.ReadString()
                };

                if (p.name == name)
                {
                    Person s = new Person();

                    Console.WriteLine("\n Enter name:");
                    s.name = Console.ReadLine();
                    Console.WriteLine("\nEnter the address:");
                    s.address = Console.ReadLine();
                    Console.WriteLine("\nEnter father name:");
                    s.fatherName = Console.ReadLine();
                    Console.WriteLine("\nEnter mother name:");
                    s.motherName = Console.ReadLine();
                    Console.WriteLine("\nEnter phone no:");
                    s.mobileNo = long.Parse(Console.ReadLine());
                    Console.WriteLine("\nEnter sex:");
                    s.sex = Console.ReadLine();
                    Console.WriteLine("\nEnter e-mail:");
                    s.email = Console.ReadLine();
                    Console.WriteLine("\nEnter citizen no:");
                    s.citizenNo = Console.ReadLine();

                    writer.Write(s.name);
                    writer.Write(s.address);
                    writer.Write(s.fatherName);
                    writer.Write(s.motherName);
                    writer.Write(s.mobileNo);
                    writer.Write(s.sex);
                    writer.Write(s.email);
                    writer.Write(s.citizenNo);

                    flag = true;
                }
                else
                {
                    writer.Write(p.name);
                }
            }
        }
    }
}